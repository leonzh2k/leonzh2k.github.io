(() => {
    console.log("ready");
    let gallery = document.querySelector('#gallery');
    console.log(gallery.childElementCount);
})();